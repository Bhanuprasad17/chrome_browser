import React, { useState } from 'react';
import styled from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import TabManagement from './components/TabManagement';
import AIInnovations from './components/AIInnovations';
import Safety from './components/Safety';
import Customization from './components/Customization';
import GoogleBuilt from './components/GoogleBuilt';
import FAQ from './components/FAQ';
import Footer from './components/Footer';

const AppContainer = styled.div`
  font-family: 'Google Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
  overflow-x: hidden;
`;

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <AppContainer>
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {/* Mobile menu would go here */}
          </motion.div>
        )}
      </AnimatePresence>
      <Hero />
      <Features />
      <TabManagement />
      <AIInnovations />
      <Safety />
      <Customization />
      <GoogleBuilt />
      <FAQ />
      <Footer />
    </AppContainer>
  );
}

export default App;
