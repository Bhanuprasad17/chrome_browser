import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const GoogleBuiltSection = styled.section`
  padding: 6rem 2rem;
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 700;
  color: #202124;
  margin-bottom: 1rem;
`;

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: 1.3rem;
  color: #5f6368;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`;

const GoogleFeaturesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 3rem;
  margin-top: 4rem;
`;

const GoogleFeatureCard = styled(motion.div)`
  background: white;
  padding: 2.5rem;
  border-radius: 20px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
  text-align: center;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #4285f4, #34a853, #fbbc05, #ea4335);
  }
  
  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
  }
`;

const GoogleIcon = styled.div`
  width: 80px;
  height: 80px;
  margin: 0 auto 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: linear-gradient(135deg, #1a73e8, #34a853);
  color: white;
  font-size: 2rem;
`;

const GoogleFeatureTitle = styled.h3`
  font-size: 1.5rem;
  font-weight: 600;
  color: #202124;
  margin-bottom: 1rem;
`;

const GoogleFeatureDescription = styled.p`
  color: #5f6368;
  line-height: 1.6;
  font-size: 1rem;
  margin-bottom: 1.5rem;
`;

const GoogleFeatureList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  text-align: left;
`;

const GoogleFeatureItem = styled.li`
  color: #5f6368;
  margin-bottom: 0.5rem;
  padding-left: 1.5rem;
  position: relative;
  
  &::before {
    content: '•';
    color: #34a853;
    font-weight: bold;
    position: absolute;
    left: 0;
  }
`;

const GoogleBuilt = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const googleFeatures = [
    {
      icon: "🤖",
      title: "GOOGLE AI",
      description: "Access AI superpowers while you browse. Google is integrating artificial intelligence to make our products more useful.",
      features: [
        "AI-powered search",
        "Smart suggestions",
        "Google Translate integration",
        "Responsible AI development"
      ]
    },
    {
      icon: "🔍",
      title: "Google Search",
      description: "The search bar you love, built right in. Access a world of knowledge at your fingertips.",
      features: [
        "Instant search results",
        "Weather information",
        "Math equation solving",
        "Voice search support"
      ]
    },
    {
      icon: "💼",
      title: "GOOGLE WORKSPACE",
      description: "Get things done, with or without Wi-Fi. Work seamlessly across all your devices.",
      features: [
        "Gmail integration",
        "Google Docs support",
        "Google Drive access",
        "Offline functionality"
      ]
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 60 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <GoogleBuiltSection>
      <Container>
        <SectionTitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          The browser built by Google
        </SectionTitle>
        
        <SectionSubtitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Leverage the power of Google's ecosystem for a seamless browsing experience
        </SectionSubtitle>
        
        <GoogleFeaturesGrid
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {googleFeatures.map((feature, index) => (
            <GoogleFeatureCard
              key={index}
              variants={cardVariants}
              whileHover={{ scale: 1.02 }}
            >
              <GoogleIcon>{feature.icon}</GoogleIcon>
              <GoogleFeatureTitle>{feature.title}</GoogleFeatureTitle>
              <GoogleFeatureDescription>{feature.description}</GoogleFeatureDescription>
              <GoogleFeatureList>
                {feature.features.map((item, idx) => (
                  <GoogleFeatureItem key={idx}>{item}</GoogleFeatureItem>
                ))}
              </GoogleFeatureList>
            </GoogleFeatureCard>
          ))}
        </GoogleFeaturesGrid>
      </Container>
    </GoogleBuiltSection>
  );
};

export default GoogleBuilt;
