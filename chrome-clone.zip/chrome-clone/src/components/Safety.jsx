import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const SafetySection = styled.section`
  padding: 6rem 2rem;
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 700;
  color: #202124;
  margin-bottom: 1rem;
`;

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: 1.3rem;
  color: #5f6368;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`;

const SafetyGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 3rem;
  margin-top: 4rem;
`;

const SafetyCard = styled(motion.div)`
  background: white;
  padding: 2.5rem;
  border-radius: 20px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
  text-align: center;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #1a73e8, #34a853, #fbbc05, #ea4335);
  }
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
  }
`;

const SafetyIcon = styled.div`
  width: 60px;
  height: 60px;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
  background: linear-gradient(135deg, #1a73e8, #34a853);
  color: white;
  font-size: 1.5rem;
`;

const SafetyTitle = styled.h3`
  font-size: 1.4rem;
  font-weight: 600;
  color: #202124;
  margin-bottom: 1rem;
`;

const SafetyDescription = styled.p`
  color: #5f6368;
  line-height: 1.6;
  font-size: 1rem;
  margin-bottom: 1.5rem;
`;

const SafetyFeature = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
  
  span {
    color: #34a853;
    font-size: 1.2rem;
  }
  
  p {
    color: #5f6368;
    font-size: 0.9rem;
    margin: 0;
  }
`;

const Safety = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const safetyFeatures = [
    {
      icon: "🔒",
      title: "PASSWORD MANAGER",
      description: "Use strong passwords on every site. Chrome has Google Password Manager built in, which makes it simple to save, manage and protect your passwords online.",
      features: [
        "Automatically saves passwords",
        "Generates strong passwords",
        "Syncs across devices",
        "Security alerts for breaches"
      ]
    },
    {
      icon: "🛡️",
      title: "ENHANCED SAFE BROWSING",
      description: "Get alerts about potentially dangerous sites, downloads, and extensions. Chrome will help you fix security issues before they become problems.",
      features: [
        "Real-time threat detection",
        "Download protection",
        "Extension safety checks",
        "Phishing warnings"
      ]
    },
    {
      icon: "✅",
      title: "SAFETY CHECK",
      description: "Instantly audit your Chrome security status. Check for compromised passwords, safe browsing status and available updates.",
      features: [
        "Password breach detection",
        "Safe browsing status",
        "Chrome update alerts",
        "Security recommendations"
      ]
    },
    {
      icon: "🔍",
      title: "PRIVACY GUIDE",
      description: "Keep your privacy under your control with easy-to-use settings. Chrome makes it easy to understand exactly what you're sharing online.",
      features: [
        "Step-by-step privacy tour",
        "Clear data controls",
        "Incognito mode",
        "Third-party cookie blocking"
      ]
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 60 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <SafetySection id="safety">
      <Container>
        <SectionTitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          Stay safe while you browse
        </SectionTitle>
        
        <SectionSubtitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Chrome uses cutting-edge safety and security features to help you manage your safety
        </SectionSubtitle>
        
        <SafetyGrid
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {safetyFeatures.map((feature, index) => (
            <SafetyCard
              key={index}
              variants={cardVariants}
              whileHover={{ scale: 1.02 }}
            >
              <SafetyIcon>{feature.icon}</SafetyIcon>
              <SafetyTitle>{feature.title}</SafetyTitle>
              <SafetyDescription>{feature.description}</SafetyDescription>
              {feature.features.map((item, idx) => (
                <SafetyFeature key={idx}>
                  <span>✓</span>
                  <p>{item}</p>
                </SafetyFeature>
              ))}
            </SafetyCard>
          ))}
        </SafetyGrid>
      </Container>
    </SafetySection>
  );
};

export default Safety; 