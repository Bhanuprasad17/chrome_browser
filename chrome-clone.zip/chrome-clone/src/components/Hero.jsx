import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';

const HeroSection = styled.section`
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  padding: 2rem;
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
  position: relative;
  overflow: hidden;
`;

const HeroContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  z-index: 2;
`;

const MainTitle = styled(motion.h1)`
  font-size: clamp(3rem, 8vw, 6rem);
  font-weight: 700;
  color: #202124;
  margin-bottom: 1rem;
  line-height: 1.1;
`;

const AnimatedText = styled(motion.span)`
  display: inline-block;
  color: #1a73e8;
  position: relative;
  
  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #1a73e8, #34a853, #fbbc05, #ea4335);
    border-radius: 2px;
  }
`;

const Subtitle = styled(motion.p)`
  font-size: clamp(1.2rem, 3vw, 1.8rem);
  color: #5f6368;
  margin-bottom: 3rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
  line-height: 1.5;
`;

const CTAButtons = styled(motion.div)`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  justify-content: center;
  margin-bottom: 3rem;
`;

const PrimaryButton = styled(motion.button)`
  background: #1a73e8;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 28px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #1557b0;
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(26, 115, 232, 0.3);
  }
`;

const SecondaryButton = styled(motion.button)`
  background: transparent;
  color: #1a73e8;
  border: 2px solid #1a73e8;
  padding: 1rem 2rem;
  border-radius: 28px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #1a73e8;
    color: white;
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(26, 115, 232, 0.3);
  }
`;

const FloatingElements = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
`;

const FloatingCircle = styled(motion.div)`
  position: absolute;
  border-radius: 50%;
  background: linear-gradient(45deg, #4285f4, #34a853);
  opacity: 0.1;
`;

const AnimationControl = styled(motion.button)`
  position: absolute;
  top: 20px;
  right: 20px;
  background: rgba(255, 255, 255, 0.9);
  border: 1px solid #e8eaed;
  border-radius: 20px;
  padding: 0.5rem 1rem;
  font-size: 0.9rem;
  color: #5f6368;
  cursor: pointer;
  z-index: 10;
  transition: all 0.3s ease;
  
  &:hover {
    background: white;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  }
`;

const Hero = () => {
  const [isAnimating, setIsAnimating] = useState(true);

  const textVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.8,
        ease: "easeOut"
      }
    })
  };

  const buttonVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  const floatingVariants = {
    animate: {
      y: [0, -20, 0],
      rotate: [0, 180, 360],
      transition: {
        duration: 20,
        repeat: Infinity,
        ease: "linear"
      }
    },
    paused: {
      y: 0,
      rotate: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  const toggleAnimation = () => {
    setIsAnimating(!isAnimating);
  };

  return (
    <HeroSection>
      <AnimationControl
        onClick={toggleAnimation}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {isAnimating ? 'Pause Animation' : 'Play Animation'}
      </AnimationControl>
      
      <FloatingElements>
        <FloatingCircle
          style={{ width: '100px', height: '100px', top: '10%', left: '10%' }}
          variants={floatingVariants}
          animate={isAnimating ? "animate" : "paused"}
        />
        <FloatingCircle
          style={{ width: '150px', height: '150px', top: '20%', right: '15%' }}
          variants={floatingVariants}
          animate={isAnimating ? "animate" : "paused"}
          transition={{ delay: 5 }}
        />
        <FloatingCircle
          style={{ width: '80px', height: '80px', bottom: '20%', left: '20%' }}
          variants={floatingVariants}
          animate={isAnimating ? "animate" : "paused"}
          transition={{ delay: 10 }}
        />
      </FloatingElements>
      
      <HeroContent>
        <MainTitle
          initial="hidden"
          animate="visible"
          variants={textVariants}
          custom={0}
        >
          The browser built to be{' '}
          <AnimatedText
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1, duration: 0.8 }}
          >
            fast
          </AnimatedText>{' '}
          <AnimatedText
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1.2, duration: 0.8 }}
          >
            safe
          </AnimatedText>{' '}
          <AnimatedText
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1.4, duration: 0.8 }}
          >
            yours
          </AnimatedText>
        </MainTitle>
        
        <Subtitle
          initial="hidden"
          animate="visible"
          variants={textVariants}
          custom={1}
        >
          Experience the web with speed, security, and personalization that puts you in control.
        </Subtitle>
        
        <CTAButtons
          initial="hidden"
          animate="visible"
          variants={buttonVariants}
        >
          <PrimaryButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get Chrome
          </PrimaryButton>
          <SecondaryButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Download Chrome
          </SecondaryButton>
        </CTAButtons>
      </HeroContent>
    </HeroSection>
  );
};

export default Hero; 