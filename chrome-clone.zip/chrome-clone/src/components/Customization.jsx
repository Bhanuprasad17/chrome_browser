import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const CustomizationSection = styled.section`
  padding: 6rem 2rem;
  background: white;
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 700;
  color: #202124;
  margin-bottom: 1rem;
`;

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: 1.3rem;
  color: #5f6368;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`;

const CustomizationGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  margin-top: 4rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
`;

const CustomizationContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2rem;
`;

const CustomizationCard = styled(motion.div)`
  background: #f8f9fa;
  padding: 2rem;
  border-radius: 16px;
  border-left: 4px solid #1a73e8;
  
  &:hover {
    background: #e9ecef;
    transform: translateX(10px);
    transition: all 0.3s ease;
  }
`;

const CardTitle = styled.h3`
  font-size: 1.3rem;
  font-weight: 600;
  color: #202124;
  margin-bottom: 1rem;
`;

const CardDescription = styled.p`
  color: #5f6368;
  line-height: 1.6;
  font-size: 1rem;
`;

const CustomizationVisual = styled(motion.div)`
  display: flex;
  flex-direction: column;
  gap: 2rem;
  align-items: center;
`;

const ThemeSection = styled.div`
  text-align: center;
  margin-bottom: 2rem;
`;

const ThemeTitle = styled.h4`
  font-size: 1.2rem;
  color: #202124;
  margin-bottom: 1rem;
`;

const ThemeGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  max-width: 300px;
`;

const ThemePreview = styled(motion.div)`
  width: 80px;
  height: 80px;
  border-radius: 12px;
  cursor: pointer;
  border: 3px solid transparent;
  transition: all 0.3s ease;
  position: relative;
  
  &:hover {
    border-color: #1a73e8;
    transform: scale(1.1);
  }
  
  &.active {
    border-color: #1a73e8;
    box-shadow: 0 4px 12px rgba(26, 115, 232, 0.3);
  }
`;

const SyncDemo = styled.div`
  background: #f8f9fa;
  padding: 1.5rem;
  border-radius: 12px;
  text-align: center;
  border: 2px solid #e8eaed;
`;

const SyncIcon = styled.div`
  font-size: 2rem;
  margin-bottom: 0.5rem;
`;

const SyncText = styled.p`
  color: #5f6368;
  font-size: 0.9rem;
  margin: 0;
`;

const themes = [
  { color: '#ffffff', name: 'Light' },
  { color: '#202124', name: 'Dark' },
  { color: '#f8f9fa', name: 'System' },
  { color: '#e8f5e8', name: 'Nature' },
  { color: '#fff3e0', name: 'Sunset' },
  { color: '#f3e5f5', name: 'Lavender' }
];

const Customization = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [activeTheme, setActiveTheme] = useState(0);

  const customizationFeatures = [
    {
      title: "Customise your Chrome",
      description: "Personalise your web browser with themes, dark mode and other options built just for you."
    },
    {
      title: "Browse across devices",
      description: "Sign in to Chrome on any device to access your bookmarks, saved passwords and more."
    },
    {
      title: "Save time with autofill",
      description: "Use Chrome to save addresses, passwords and more to quickly autofill your details."
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, x: -30 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  const visualVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <CustomizationSection id="customization">
      <Container>
        <SectionTitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          Make it yours and take it with you
        </SectionTitle>
        
        <SectionSubtitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Personalize Chrome to match your style and sync across all your devices
        </SectionSubtitle>
        
        <CustomizationGrid
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          <CustomizationContent>
            {customizationFeatures.map((feature, index) => (
              <CustomizationCard
                key={index}
                variants={cardVariants}
                whileHover={{ scale: 1.02 }}
              >
                <CardTitle>{feature.title}</CardTitle>
                <CardDescription>{feature.description}</CardDescription>
              </CustomizationCard>
            ))}
          </CustomizationContent>
          
          <CustomizationVisual variants={visualVariants}>
            <ThemeSection>
              <ThemeTitle>Choose Your Theme</ThemeTitle>
              <ThemeGrid>
                {themes.map((theme, index) => (
                  <ThemePreview
                    key={index}
                    style={{ backgroundColor: theme.color }}
                    className={activeTheme === index ? 'active' : ''}
                    onClick={() => setActiveTheme(index)}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    title={theme.name}
                  />
                ))}
              </ThemeGrid>
            </ThemeSection>
            
            <SyncDemo>
              <SyncIcon>📱💻</SyncIcon>
              <SyncText>Your tabs sync automatically across devices</SyncText>
            </SyncDemo>
          </CustomizationVisual>
        </CustomizationGrid>
      </Container>
    </CustomizationSection>
  );
};

export default Customization; 