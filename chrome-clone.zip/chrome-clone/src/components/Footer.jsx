import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';

const FooterSection = styled.footer`
  padding: 4rem 2rem 2rem;
  background: #202124;
  color: white;
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const FooterTop = styled.div`
  text-align: center;
  margin-bottom: 3rem;
`;

const FooterTitle = styled.h2`
  font-size: clamp(2rem, 4vw, 2.5rem);
  font-weight: 700;
  margin-bottom: 1rem;
`;

const FooterSubtitle = styled.p`
  font-size: 1.2rem;
  color: #9aa0a6;
  margin-bottom: 2rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`;

const DownloadButtons = styled.div`
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
  margin-bottom: 3rem;
`;

const DownloadButton = styled(motion.button)`
  background: #1a73e8;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 28px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #1557b0;
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(26, 115, 232, 0.3);
  }
`;

const SecondaryButton = styled(motion.button)`
  background: transparent;
  color: #1a73e8;
  border: 2px solid #1a73e8;
  padding: 1rem 2rem;
  border-radius: 28px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #1a73e8;
    color: white;
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(26, 115, 232, 0.3);
  }
`;

const QRCodeSection = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 2rem;
  margin: 2rem 0;
  flex-wrap: wrap;
`;

const QRCode = styled.div`
  background: white;
  width: 120px;
  height: 120px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 3rem;
  color: #202124;
`;

const QRText = styled.div`
  text-align: center;
  
  h4 {
    color: #9aa0a6;
    margin-bottom: 0.5rem;
    font-size: 1rem;
  }
  
  p {
    color: #9aa0a6;
    font-size: 0.9rem;
    margin: 0;
  }
`;

const FooterBottom = styled.div`
  border-top: 1px solid #3c4043;
  padding-top: 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 1rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
    text-align: center;
  }
`;

const Copyright = styled.p`
  color: #9aa0a6;
  margin: 0;
`;

const SocialLinks = styled.div`
  display: flex;
  gap: 1rem;
`;

const SocialLink = styled(motion.a)`
  color: #9aa0a6;
  text-decoration: none;
  font-size: 1.2rem;
  
  &:hover {
    color: #1a73e8;
  }
`;

const Footer = () => {
  return (
    <FooterSection>
      <Container>
        <FooterTop>
          <FooterTitle>Take your browser with you</FooterTitle>
          <FooterSubtitle>
            Download Chrome on your mobile device or tablet and sign into your account for the same browser experience, everywhere.
          </FooterSubtitle>
          
          <DownloadButtons>
            <DownloadButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Get Chrome
            </DownloadButton>
            <SecondaryButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Download Chrome
            </SecondaryButton>
          </DownloadButtons>
          
          <QRCodeSection>
            <div>
              <QRCode>📱</QRCode>
              <QRText>
                <h4>Android</h4>
                <p>Scan to download</p>
              </QRText>
            </div>
            <div>
              <QRCode>🍎</QRCode>
              <QRText>
                <h4>iOS</h4>
                <p>Scan to download</p>
              </QRText>
            </div>
          </QRCodeSection>
        </FooterTop>
        
        <FooterBottom>
          <Copyright>
            © 2024 Google LLC. All rights reserved.
          </Copyright>
          
          <SocialLinks>
            <SocialLink
              href="#"
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            >
              📱
            </SocialLink>
            <SocialLink
              href="#"
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            >
              💻
            </SocialLink>
            <SocialLink
              href="#"
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            >
              🔗
            </SocialLink>
          </SocialLinks>
        </FooterBottom>
      </Container>
    </FooterSection>
  );
};

export default Footer;
