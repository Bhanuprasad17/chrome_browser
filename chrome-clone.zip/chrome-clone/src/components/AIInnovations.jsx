import React, { useState } from 'react';
import styled from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const AISection = styled.section`
  padding: 6rem 2rem;
  background: white;
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 700;
  color: #202124;
  margin-bottom: 1rem;
`;

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: 1.3rem;
  color: #5f6368;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`;

const AIGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 3rem;
  margin-top: 4rem;
`;

const AICard = styled(motion.div)`
  background: white;
  padding: 2.5rem;
  border-radius: 20px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
  text-align: center;
  position: relative;
  overflow: hidden;
  cursor: pointer;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #4285f4, #34a853, #fbbc05, #ea4335);
  }
  
  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
  }
`;

const AIIcon = styled(motion.div)`
  width: 80px;
  height: 80px;
  margin: 0 auto 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: linear-gradient(135deg, #1a73e8, #34a853);
  color: white;
  font-size: 2rem;
  position: relative;
`;

const AITitle = styled.h3`
  font-size: 1.5rem;
  font-weight: 600;
  color: #202124;
  margin-bottom: 1rem;
`;

const AIDescription = styled.p`
  color: #5f6368;
  line-height: 1.6;
  font-size: 1rem;
  margin-bottom: 1.5rem;
`;

const AIDemo = styled(motion.div)`
  background: #f8f9fa;
  padding: 1.5rem;
  border-radius: 12px;
  margin-top: 1rem;
  border: 2px solid transparent;
  transition: all 0.3s ease;
  
  &.active {
    border-color: #1a73e8;
    background: #e8f0fe;
  }
`;

const DemoContent = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 1rem;
`;

const DemoImage = styled(motion.div)`
  width: 60px;
  height: 60px;
  border-radius: 8px;
  background: ${props => props.background || '#e8f5e8'};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
`;

const DemoText = styled.p`
  font-size: 0.9rem;
  color: #5f6368;
  margin: 0;
  font-weight: 500;
`;

const GeminiHighlight = styled(motion.div)`
  background: linear-gradient(135deg, #1a73e8, #34a853);
  color: white;
  padding: 2rem;
  border-radius: 20px;
  text-align: center;
  margin: 4rem 0;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
    animation: float 20s linear infinite;
  }
  
  @keyframes float {
    0% { transform: translateY(0px); }
    100% { transform: translateY(-100px); }
  }
`;

const GeminiTitle = styled.h3`
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 1rem;
  position: relative;
  z-index: 1;
`;

const GeminiDescription = styled.p`
  font-size: 1.2rem;
  margin-bottom: 1.5rem;
  position: relative;
  z-index: 1;
`;

const GeminiButton = styled(motion.button)`
  background: white;
  color: #1a73e8;
  border: none;
  padding: 1rem 2rem;
  border-radius: 28px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  position: relative;
  z-index: 1;
  
  &:hover {
    background: #f8f9fa;
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(255, 255, 255, 0.3);
  }
`;

const AIInnovations = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [activeDemo, setActiveDemo] = useState(null);

  const aiFeatures = [
    {
      icon: "🔍",
      title: "Google Lens",
      description: "Identify objects, translate text, and get information just by pointing your camera at them.",
      demo: {
        image: "🌿",
        background: "#e8f5e8",
        text: "Point camera at plant",
        active: "Plant identified: Monstera Deliciosa"
      }
    },
    {
      icon: "🎨",
      title: "Generative Themes",
      description: "Create personalized browser themes using AI-generated artwork and colors.",
      demo: {
        image: "🎭",
        background: "#fff3e0",
        text: "Generate theme",
        active: "New theme created with AI-generated artwork"
      }
    },
    {
      icon: "🤖",
      title: "Gemini Assistant",
      description: "Get AI-powered help with writing, research, and creative tasks directly in Chrome.",
      demo: {
        image: "💬",
        background: "#f3e5f5",
        text: "Ask Gemini",
        active: "Gemini is helping you with your request"
      }
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 60 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  const handleCardClick = (index) => {
    setActiveDemo(activeDemo === index ? null : index);
  };

  return (
    <AISection id="ai-innovations">
      <Container>
        <SectionTitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          Meet Gemini in Chrome
        </SectionTitle>
        
        <SectionSubtitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Access AI superpowers while you browse with intelligent tools built right into Chrome
        </SectionSubtitle>
        
        <GeminiHighlight
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <GeminiTitle>🤖 Gemini is here to help</GeminiTitle>
          <GeminiDescription>
            Experience the future of browsing with AI-powered assistance that makes the web more useful and accessible.
          </GeminiDescription>
          <GeminiButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Try Gemini Now
          </GeminiButton>
        </GeminiHighlight>
        
        <AIGrid
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {aiFeatures.map((feature, index) => (
            <AICard
              key={index}
              variants={cardVariants}
              onClick={() => handleCardClick(index)}
              whileHover={{ scale: 1.02 }}
            >
              <AIIcon
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                {feature.icon}
              </AIIcon>
              <AITitle>{feature.title}</AITitle>
              <AIDescription>{feature.description}</AIDescription>
              
              <AIDemo
                className={activeDemo === index ? 'active' : ''}
                initial={{ opacity: 0, height: 0 }}
                animate={{ 
                  opacity: 1, 
                  height: "auto",
                  transition: { duration: 0.3 }
                }}
              >
                <DemoContent>
                  <DemoImage
                    background={feature.demo.background}
                    whileHover={{ scale: 1.1 }}
                  >
                    {feature.demo.image}
                  </DemoImage>
                  <DemoText>
                    {activeDemo === index ? feature.demo.active : feature.demo.text}
                  </DemoText>
                </DemoContent>
              </AIDemo>
            </AICard>
          ))}
        </AIGrid>
      </Container>
    </AISection>
  );
};

export default AIInnovations;
