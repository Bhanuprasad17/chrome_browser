import React, { useState } from 'react';
import styled from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const TabSection = styled.section`
  padding: 6rem 2rem;
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 700;
  color: #202124;
  margin-bottom: 1rem;
`;

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: 1.3rem;
  color: #5f6368;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`;

const TabDemoContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  margin-top: 4rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
`;

const TabDemo = styled(motion.div)`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden;
`;

const BrowserBar = styled.div`
  background: #f1f3f4;
  height: 40px;
  border-radius: 8px 8px 0 0;
  display: flex;
  align-items: center;
  padding: 0 1rem;
  gap: 0.5rem;
  margin-bottom: 1rem;
`;

const Tab = styled(motion.div)`
  background: ${props => props.isActive ? 'white' : '#e8eaed'};
  color: ${props => props.isActive ? '#202124' : '#5f6368'};
  padding: 0.5rem 1rem;
  border-radius: 8px 8px 0 0;
  font-size: 0.9rem;
  cursor: pointer;
  position: relative;
  border: 1px solid ${props => props.isActive ? '#dadce0' : 'transparent'};
  
  &:hover {
    background: ${props => props.isActive ? 'white' : '#dadce0'};
  }
`;

const TabGroup = styled(motion.div)`
  display: flex;
  gap: 0.25rem;
  margin-bottom: 1rem;
  position: relative;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: ${props => props.color || '#1a73e8'};
    border-radius: 2px;
  }
`;

const TabContent = styled.div`
  background: white;
  height: 200px;
  border-radius: 0 0 8px 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #5f6368;
  font-size: 0.9rem;
`;

const TabFeatures = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const FeatureItem = styled(motion.div)`
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 12px;
  border-left: 4px solid #1a73e8;
  
  &:hover {
    background: #e8f0fe;
    transform: translateX(5px);
    transition: all 0.3s ease;
  }
`;

const FeatureIcon = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #1a73e8, #34a853);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
`;

const FeatureText = styled.div`
  h4 {
    margin: 0 0 0.25rem 0;
    color: #202124;
    font-size: 1rem;
  }
  
  p {
    margin: 0;
    color: #5f6368;
    font-size: 0.9rem;
  }
`;

const TabManagement = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [activeTabGroup, setActiveTabGroup] = useState(0);

  const tabGroups = [
    {
      id: 0,
      color: '#1a73e8',
      tabs: ['Gmail', 'Calendar', 'Drive'],
      label: 'Work'
    },
    {
      id: 1,
      color: '#34a853',
      tabs: ['YouTube', 'Maps', 'Photos'],
      label: 'Personal'
    },
    {
      id: 2,
      color: '#fbbc05',
      tabs: ['News', 'Weather', 'Sports'],
      label: 'Info'
    }
  ];

  const features = [
    {
      icon: "🏷️",
      title: "Smart Grouping",
      description: "Automatically organize tabs by topic or purpose"
    },
    {
      icon: "🎨",
      title: "Color Coding",
      description: "Assign colors to different tab groups for easy identification"
    },
    {
      icon: "📱",
      title: "Cross-Device Sync",
      description: "Access your organized tabs on any device"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <TabSection id="tab-management">
      <Container>
        <SectionTitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          Stay organized with smart tab management
        </SectionTitle>
        
        <SectionSubtitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Group, label, and color-code your tabs for a clutter-free browsing experience
        </SectionSubtitle>
        
        <TabDemoContainer
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          <TabDemo variants={itemVariants}>
            <BrowserBar>
              {tabGroups.map((group, index) => (
                <TabGroup
                  key={group.id}
                  color={group.color}
                  onClick={() => setActiveTabGroup(index)}
                  whileHover={{ scale: 1.02 }}
                >
                  {group.tabs.map((tab, tabIndex) => (
                    <Tab
                      key={tabIndex}
                      isActive={activeTabGroup === index}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {tab}
                    </Tab>
                  ))}
                </TabGroup>
              ))}
            </BrowserBar>
            <TabContent>
              {activeTabGroup === 0 && "Work tabs: Gmail, Calendar, Drive"}
              {activeTabGroup === 1 && "Personal tabs: YouTube, Maps, Photos"}
              {activeTabGroup === 2 && "Info tabs: News, Weather, Sports"}
            </TabContent>
          </TabDemo>
          
          <TabFeatures>
            {features.map((feature, index) => (
              <FeatureItem
                key={index}
                variants={itemVariants}
                whileHover={{ scale: 1.02 }}
              >
                <FeatureIcon>{feature.icon}</FeatureIcon>
                <FeatureText>
                  <h4>{feature.title}</h4>
                  <p>{feature.description}</p>
                </FeatureText>
              </FeatureItem>
            ))}
          </TabFeatures>
        </TabDemoContainer>
      </Container>
    </TabSection>
  );
};

export default TabManagement;
