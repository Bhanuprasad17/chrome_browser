import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const FeaturesSection = styled.section`
  padding: 6rem 2rem;
  background: white;
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const SectionTitle = styled(motion.h2)`
  text-align: center;
  font-size: clamp(2.5rem, 5vw, 3.5rem);
  font-weight: 700;
  color: #202124;
  margin-bottom: 1rem;
`;

const SectionSubtitle = styled(motion.p)`
  text-align: center;
  font-size: 1.3rem;
  color: #5f6368;
  margin-bottom: 4rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`;

const FeaturesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 3rem;
  margin-top: 4rem;
`;

const FeatureCard = styled(motion.div)`
  background: white;
  padding: 2.5rem;
  border-radius: 20px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
  text-align: center;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  
  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
  }
`;

const FeatureIcon = styled(motion.div)`
  width: 80px;
  height: 80px;
  margin: 0 auto 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: linear-gradient(135deg, #1a73e8, #34a853);
  color: white;
  font-size: 2rem;
  cursor: pointer;
  position: relative;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: 50%;
    background: rgba(26, 115, 232, 0.2);
    transform: scale(0);
    transition: transform 0.3s ease;
  }
  
  &:hover::before {
    transform: scale(1.2);
  }
`;

const FeatureTitle = styled.h3`
  font-size: 1.5rem;
  font-weight: 600;
  color: #202124;
  margin-bottom: 1rem;
`;

const FeatureDescription = styled.p`
  color: #5f6368;
  line-height: 1.6;
  font-size: 1rem;
  margin-bottom: 1.5rem;
`;

const InteractiveDemo = styled(motion.div)`
  background: #f8f9fa;
  padding: 1rem;
  border-radius: 12px;
  margin-top: 1rem;
  border: 2px solid transparent;
  transition: all 0.3s ease;
  
  &.active {
    border-color: #1a73e8;
    background: #e8f0fe;
  }
`;

const DemoText = styled.p`
  font-size: 0.9rem;
  color: #5f6368;
  margin: 0;
  font-weight: 500;
`;

const Features = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [activeFeature, setActiveFeature] = useState(null);

  const features = [
    {
      icon: "⚡",
      title: "Energy Saver",
      description: "Chrome is built for performance. Optimise your experience with Energy Saver to extend battery life and reduce system resource usage.",
      demoText: "Click the Energy Saver icon to see power optimization in action",
      demoActive: "Energy Saver activated! Your browser is now optimized for battery life."
    },
    {
      icon: "💾",
      title: "Memory Saver",
      description: "Chrome has intelligent memory management that automatically frees up RAM from inactive tabs, keeping your system running smoothly.",
      demoText: "Watch as Chrome automatically manages memory for inactive tabs",
      demoActive: "Memory Saver working! Inactive tabs are now suspended to free up RAM."
    },
    {
      icon: "🚀",
      title: "Performance Boost",
      description: "Experience lightning-fast browsing with Chrome's performance optimizations and hardware acceleration.",
      demoText: "See the performance improvements in real-time",
      demoActive: "Performance mode enabled! Pages load faster with optimized rendering."
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  const handleFeatureClick = (index) => {
    setActiveFeature(activeFeature === index ? null : index);
  };

  return (
    <FeaturesSection id="features">
      <Container>
        <SectionTitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          Fast performance, optimized for you
        </SectionTitle>
        
        <SectionSubtitle
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Experience lightning-fast browsing with Chrome's intelligent performance features
        </SectionSubtitle>
        
        <FeaturesGrid
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              variants={cardVariants}
              whileHover={{ scale: 1.02 }}
            >
              <FeatureIcon
                onClick={() => handleFeatureClick(index)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                {feature.icon}
              </FeatureIcon>
              <FeatureTitle>{feature.title}</FeatureTitle>
              <FeatureDescription>{feature.description}</FeatureDescription>
              
              <InteractiveDemo
                className={activeFeature === index ? 'active' : ''}
                initial={{ opacity: 0, height: 0 }}
                animate={{ 
                  opacity: 1, 
                  height: "auto",
                  transition: { duration: 0.3 }
                }}
              >
                <DemoText>
                  {activeFeature === index ? feature.demoActive : feature.demoText}
                </DemoText>
              </InteractiveDemo>
            </FeatureCard>
          ))}
        </FeaturesGrid>
      </Container>
    </FeaturesSection>
  );
};

export default Features; 