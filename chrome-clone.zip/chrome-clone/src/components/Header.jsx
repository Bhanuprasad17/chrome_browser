import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';

const HeaderContainer = styled.header`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  z-index: 1000;
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
`;

const Logo = styled(motion.div)`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  
  span {
    font-size: 1.5rem;
    font-weight: 500;
    color: #1a73e8;
  }
`;

const Nav = styled.nav`
  display: flex;
  gap: 2rem;
  
  @media (max-width: 768px) {
    display: none;
  }
`;

const NavLink = styled(motion.a)`
  text-decoration: none;
  color: #5f6368;
  font-weight: 500;
  cursor: pointer;
  position: relative;
  
  &:hover {
    color: #1a73e8;
  }
  
  &::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 2px;
    background: #1a73e8;
    transition: width 0.3s ease;
  }
  
  &:hover::after {
    width: 100%;
  }
`;

const DownloadButton = styled(motion.button)`
  background: #1a73e8;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 24px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #1557b0;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(26, 115, 232, 0.3);
  }
`;

const MobileMenuButton = styled.button`
  display: none;
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  
  @media (max-width: 768px) {
    display: block;
  }
`;

const Header = ({ isMenuOpen, setIsMenuOpen }) => {
  return (
    <HeaderContainer>
      <Logo
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
          <circle cx="16" cy="16" r="16" fill="#4285F4"/>
          <circle cx="16" cy="16" r="12" fill="#34A853"/>
          <circle cx="16" cy="16" r="8" fill="#FBBC05"/>
          <circle cx="16" cy="16" r="4" fill="#EA4335"/>
        </svg>
        <span>Google</span>
      </Logo>
      
      <Nav>
        <NavLink
          href="#safety"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Safety
        </NavLink>
        <NavLink
          href="#by-google"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          By Google
        </NavLink>
        <NavLink
          href="#extensions"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Extensions
        </NavLink>
      </Nav>
      
      <DownloadButton
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        Get Chrome
      </DownloadButton>
      
      <MobileMenuButton onClick={() => setIsMenuOpen(!isMenuOpen)}>
        ☰
      </MobileMenuButton>
    </HeaderContainer>
  );
};

export default Header; 